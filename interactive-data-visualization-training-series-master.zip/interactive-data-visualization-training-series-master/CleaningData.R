# Loading in & cleaning covid-19 dataset from "Our world in data" 

library(readr)
library(ggplot2)
library(dplyr)

owid_covid_data <- read_csv("2- Develop a Power BI dashboard /owid-covid-data.csv")
View(owid_covid_data) 


# create line graph for vaccination progress over time 

# xValue <- owid_covid_data$date
xValue <- 1:length(owid_covid_data$date)
yValue <- owid_covid_data$people_fully_vaccinated

invalid = is.na(yValue)
xValue <- xValue[!invalid]
yValue <- yValue[!invalid]

data <- data.frame(xValue,yValue)

# Plot
p <- ggplot(data, aes(x=xValue, y=yValue))
p <- p + geom_line()
print(p)





# create line graph for new cases over time 

