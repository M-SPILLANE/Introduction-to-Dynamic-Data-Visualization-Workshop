**About this Training Series**
-----
*Interactive Data Visualization* is organized into 5 modules: an intro session, a peer into the world of GIS/mapping, two interactive workshops where we will build a dashboard and application together, a CDC-specific publishing guide, and finally, a capstone to test out our new dataviz skills. Each module folder contains all of the data and code needed to follow along during the interactive workshops.

*Who is this training series for?*

- Those who are completely new to data visualization and would like to add some new analytical skills to their toolbox 
- Those who have some experience building dashboards & apps but would like to learn some new tricks and get a refresher on CDC specific protocols
- Dataviz experts who are passionate about sharing their knowledge and would like to be involved in this fun conversation

*What will I gain from completing this series?*
- You will be able to build a dashboard and app on your own 
- You will have learned multiple software tools 
- You will improve your ability to communicate data insights effectively 
- You will master the art of dashboard demos
- You will learn or be reminded of dataviz best practices 
- You will gain a better understanding of development & design strategies 
- You will be equipped with resources and the CDC data viz community for support 
- You will (hopefully) learn something new :)

*What will this training not cover?*
- We will assume that you have a working knowledge in statistics and data wrangling. Hence, these topics will not be covered in our training series

The table below shows our _tentative_ schedule for the training series: 
| Module                                                      | Date             |
| ------                                                      |-----             |
| 1.  Introduction to dynamic data visualization              | Feb 25th, 2022   |
| 1b. Carmen's overview of GIS and mapping                    | Mar  4th, 2022   |
| 2.  Develop a Power BI dashboard                            | Mar 18th, 2022   |
| 3.  Develop an R Shiny application                          | Apr  1st, 2022   |
| 4.  DataViz publishing at CDC                               | Apr 15th, 2022   |
| 5.  Capstone project & dashboard competition                | Apr 22nd, 2022   |
